// These all do the same function but for different pages. They
// Make the forms that edit update and add pop up. 

function openForm() {
  document.getElementById("myForm").style.visibility = "visible";
}

function closeForm() {
  document.getElementById("myForm").style.visibility = "hidden";
}


function openEditForm() {
  document.getElementById("myEditForm").style.visibility = "visible";
}

function closeEditForm() {
  document.getElementById("myEditForm").style.visibility = "hidden";
}


function openEditFormNote() {
  document.getElementById("myFormNoteEdit").style.visibility = "visible";
}

function closeEditFormNote() {
  document.getElementById("myFormNoteEdit").style.visibility = "hidden";
}


