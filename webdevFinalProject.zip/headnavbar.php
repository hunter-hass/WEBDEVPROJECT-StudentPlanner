
<!-- Nav bar -->
<header>
  <h1>Magic Planner</h1>
  <div id="head-nav-bar">
    <nav>
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="planner.php">Planner</a></li>
        <li><a href="notes.php">Notes</a></li>
        <li><a href="sharenotes.php">Share Notes</a></li>
      </ul>
    </nav>
    <div id="logout">
      <a href="logout.php">Logout</a>
    </div>
  </div>
</header>
